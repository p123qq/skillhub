---
name: mcu-equivalence-review
description: Run formal equivalence verification (Formality/Conformal) between RTL and synthesis netlist, and review results. Use when a synthesis netlist exists and logical equivalence must be confirmed before PnR, or when equivalence failures need diagnosis.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# MCU Equivalence Review

Use this skill to run equivalence checking and review results. Covers script generation from templates, tool execution, result parsing, and mismatch classification.

## Boundaries

The following tasks are out of scope. Inform the user and, if the corresponding skill exists in the project, suggest routing there.

- Do **not** modify RTL or netlist. Fix suggestions feed back to the user. (Companion skills: `mcu-rtl-development`, `mcu-synthesis-planning`)
- Do **not** run synthesis. (Companion skill: `mcu-synthesis-planning`)
- Do **not** run PnR. (Companion skill: `mcu-pnr-implementation`)

## Good Outcome

Produce:

- equivalence verification script generated from template
- tool execution with PASS/FAIL result
- match point statistics
- mismatch classification (if FAIL)
- retry, rollback, or manual-review guidance

## Input Artifacts

| Artifact | Source | Required |
|----------|--------|----------|
| `eda_env.json` | From EDA env setup if available | Yes |
| RTL filelist (`filelist.f`) | User-provided or from RTL development stage | Yes |
| Synthesis netlist | From synthesis stage | Yes |
| SVF guidance file | From DC synthesis (Genus does not produce SVF) | Recommended |
| Black-box module list | `doc/spec.md` | Recommended |

## Output Artifacts

| Artifact | Path | Description |
|----------|------|-------------|
| Verification script | `scripts/fm_verify.tcl` or `scripts/lec_verify.do` | Generated from template |
| Status report | `rpt/fm_status.rpt` or `rpt/lec_status.rpt` | PASS/FAIL result |
| Failing points | `rpt/fm_failing.rpt` | Compare-point failures (if FAIL) |
| Log | `rpt/fm.log` | Full tool log |

## Input Validation

### From eda_env.json

| Required field | What to check | Used for |
|---|---|---|
| `selected_tools.equivalence` | Not null, one of: formality, conformal | Template and command selection |
| `available_tools[]` for equivalence tool | `path` not null | Binary location |
| `libraries.std_cell` | At least one corner with .db files | Implementation library reading |

### From synthesis outputs

| Required | What to check | Used for |
|---|---|---|
| Netlist exists | `output/syn/<design>_syn.v` | Implementation design |
| SVF exists (DC) | `output/syn/<design>.svf` | Guidance for Formality |

## Workflow

### Step 1: Select tool and fill template

Read `eda_env.json → selected_tools.equivalence`:

**If Formality**: Read `scripts/fm_verify_template.tcl`, fill placeholders:

| Placeholder | Value source |
|---|---|
| `{{PROJ_HOME}}` | Project root |
| `{{TOP_MODULE}}` | spec.md → top module |
| `{{REF_FILELIST}}` | `rtl/filelist.f` (absolute path) |
| `{{IMPL_NETLIST}}` | `output/syn/<design>_syn.v` |
| `{{IMPL_DB_LIST}}` | eda_env.json → libraries .db files |
| `{{SVF_PATH}}` | `output/syn/<design>.svf` |
| `{{BLACK_BOX_CMDS}}` | Per black-box module: `set_black_box r:/WORK/<module>` + `set_black_box i:/WORK/<module>` |
| `{{RPT_DIR}}` | `rpt` |

Write filled script to `scripts/fm_verify.tcl`.

**If Conformal**: Read `scripts/conformal_verify_template.do`, fill similarly. Note: Conformal does not use SVF.

### Step 2: Execute

**Formality:**
```
fm_shell -file scripts/fm_verify.tcl 2>&1 | tee rpt/fm.log
```

**Conformal:**
```
lec -dofile scripts/lec_verify.do -log rpt/lec.log
```

### Step 3: Parse results

Check log for result markers:
- `FORMAL_RESULT:PASS` → equivalence confirmed
- `FORMAL_RESULT:FAIL` → mismatches found
- `FM_MATCHED_POINTS:<N>` / `FM_UNMATCHED_POINTS:<N>` → statistics

Use `scripts/parse_formality_status.py` for structured parsing.

### Step 4: Route result

| Result | Route to | Action |
|---|---|---|
| PASS, all points matched | `mcu-pnr-implementation` | Proceed to P&R |
| FAIL, few unmatched points | Retry with adjusted black-box list or SVF | Check setup first |
| FAIL, many unmatched points | `mcu-synthesis-planning` | Possible synthesis issue, rollback |
| Tool error | Check library paths, netlist format | Fix setup |

## Equivalence Quality Rules

### Common failure patterns

| Pattern | Likely cause | Action |
|---------|-------------|--------|
| Stale or missing SVF | SVF from a different synthesis run | Regenerate SVF from same DC run as netlist |
| Compare-point naming drift | Optimization renamed signals | Check SVF covers the transformations |
| Black-box list mismatch | Different modules treated as black-box in ref vs impl | Align black-box commands for both views |
| Constant propagation asymmetry | Optimization removed logic in only one view | Check `set_constant` or `set_dont_touch` settings |
| Post-PnR netlist drift | PnR netlist no longer matches synthesis snapshot | Use synthesis netlist as impl, not post-PnR |

### SVF and guidance checklist

- Confirm the SVF comes from the **same synthesis run** as the implementation netlist
- SVF must be loaded **before** reading any design (FM-256) — the fm_verify_template.tcl handles this
- If SVF is absent (Genus flow), use Conformal instead of Formality
- If SVF is stale, classify the result as guidance-integrity risk before deeper diagnosis

### Black-box boundary checklist

- Confirm the same protected modules are treated as black boxes in both reference and implementation views
- Confirm port lists match at every protected boundary (name, direction, width)
- Distinguish expected unverified internals (CPU core, SRAM macro) from unexpected boundary mismatch
- Black-box boundary drift is a first-class blocker — do not proceed to PnR with unresolved mismatches

## Bundled Assets

- [equivalence-review-template.md](assets/equivalence-review-template.md) — review output format
- [example-equivalence-review.md](assets/example-equivalence-review.md) — sample review output
- [sample-equivalence-summary.json](assets/sample-equivalence-summary.json) — structured summary example

## Bundled Scripts

- [fm_verify_template.tcl](scripts/fm_verify_template.tcl) — Formality TCL template (verified against MCP server)
- [conformal_verify_template.do](scripts/conformal_verify_template.do) — Conformal dofile template (result parser not bundled; parse Conformal logs manually)
- [parse_formality_status.py](scripts/parse_formality_status.py) — Formality result parser (extracts PASS/FAIL, matched/unmatched point counts)

## Completion Gate

- Verification script generated from template with project-specific values
- Tool executed, log and status report exist
- Result is PASS or FAIL with match statistics
- If FAIL: mismatch classified, next action identified

## Decision Rules

- Do not treat stale SVF or mismatched run context as proof of design mismatch.
- Treat black-box boundary drift as a first-class blocker.
- If synthesizer is Genus (not DC), SVF is unavailable — use Conformal instead of Formality.
- Back up previous reports before re-running.
