// {{GENERATED_BY}}
// Cadence Conformal (LEC) Equivalence Verification Dofile
// Design: {{DESIGN}}

//--------------------------------------------------------------
// Libraries
//--------------------------------------------------------------
read_library -liberty {{{LIB_FILES}}}

//--------------------------------------------------------------
// Golden Design (RTL)
//--------------------------------------------------------------
{{READ_GOLDEN_FILES}}
set_root_module {{TOP_MODULE}}

//--------------------------------------------------------------
// Revised Design (Netlist)
//--------------------------------------------------------------
read_design -revised {{IMPL_NETLIST}} -top {{TOP_MODULE}}

//--------------------------------------------------------------
// Black Box Modules
//--------------------------------------------------------------
{{BLACK_BOX_CMDS}}

//--------------------------------------------------------------
// Flatten and Compare
//--------------------------------------------------------------
set_flatten_model -golden
set_flatten_model -revised
add_compared_points -all
compare

//--------------------------------------------------------------
// Reports
//--------------------------------------------------------------
report_compare_data > {{RPT_DIR}}/lec_status.rpt

exit
