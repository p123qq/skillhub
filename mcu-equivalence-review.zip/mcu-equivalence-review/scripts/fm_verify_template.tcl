# {{GENERATED_BY}}
# Formality Equivalence Checking Script — generated from fm_verify_template.tcl
# Design: {{DESIGN}}
# Do not edit manually — regenerate via mcu-equivalence-review skill

set PROJ_HOME "{{PROJ_HOME}}"

# Suppress unnecessary messages
set_app_var synopsys_auto_setup true
set_app_var hdlin_unresolved_modules black_box

#-------------------------------------------------------------------------------
# SVF Guidance — MUST be set BEFORE reading any design (FM-256)
# If SVF is loaded after read_verilog, Formality silently ignores it.
#-------------------------------------------------------------------------------
set svf_file "{{SVF_PATH}}"
if {[file exists $svf_file]} {
  set_svf $svf_file
}

#-------------------------------------------------------------------------------
# Reference Design (RTL)
# Formality does not support VCS-style -f filelist. Parse filelist in TCL.
#-------------------------------------------------------------------------------
set fp [open "{{REF_FILELIST}}" r]
set fdata [read $fp]
close $fp
set ref_files [list]
foreach line [split $fdata "\n"] {
    set line [string trim $line]
    # Skip empty lines, comments, and tool options (+/-)
    if {$line eq "" || [string index $line 0] eq "#" || [string range $line 0 1] eq "//" || [string index $line 0] eq "+" || [string index $line 0] eq "-"} {
        continue
    }
    if {[string index $line 0] ne "/"} {
        lappend ref_files $PROJ_HOME/$line
    } else {
        lappend ref_files $line
    }
}
read_verilog -r $ref_files
set_top r:/WORK/{{TOP_MODULE}}

#-------------------------------------------------------------------------------
# Implementation Design (Gate-level netlist)
#-------------------------------------------------------------------------------
read_db -i [list \
{{IMPL_DB_LIST}}
]

read_verilog -i {{IMPL_NETLIST}}
set_top i:/WORK/{{TOP_MODULE}}

#-------------------------------------------------------------------------------
# Black Boxes
#-------------------------------------------------------------------------------
{{BLACK_BOX_CMDS}}

#-------------------------------------------------------------------------------
# Match & Verify
#-------------------------------------------------------------------------------
match

set result [verify]

# Report status
report_status > {{RPT_DIR}}/fm_status.rpt

# Extract match point statistics
set matched [get_matched_points -count]
set unmatched [get_unmatched_points -count]
puts "FM_MATCHED_POINTS:$matched"
puts "FM_UNMATCHED_POINTS:$unmatched"

if {$result} {
  puts "FORMAL_RESULT:PASS"
} else {
  puts "FORMAL_RESULT:FAIL"
  diagnose
  report_failing_points > {{RPT_DIR}}/fm_failing.rpt
}

exit
