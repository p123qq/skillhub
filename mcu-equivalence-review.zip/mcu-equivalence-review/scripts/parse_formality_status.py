import json
import re
import sys


def main() -> int:
    text = sys.stdin.read()

    # Detect result from structured marker (preferred) or fallback keywords
    result = "UNKNOWN"
    marker = re.search(r"FORMAL_RESULT:\s*(PASS|FAIL)", text, re.I)
    if marker:
        result = marker.group(1).upper()
    elif re.search(r"\bPASS\b", text, re.I):
        result = "PASS"
    elif re.search(r"INCONCLUSIVE", text, re.I):
        result = "INCONCLUSIVE"
    elif re.search(r"\bFAIL\b", text, re.I):
        result = "FAIL"

    # Extract match point statistics from FM_MATCHED_POINTS / FM_UNMATCHED_POINTS
    matched = None
    unmatched = None
    m_match = re.search(r"FM_MATCHED_POINTS:\s*(\d+)", text)
    if m_match:
        matched = int(m_match.group(1))
    m_unmatch = re.search(r"FM_UNMATCHED_POINTS:\s*(\d+)", text)
    if m_unmatch:
        unmatched = int(m_unmatch.group(1))

    payload = {
        "result": result,
        "matched_points": matched,
        "unmatched_points": unmatched,
        "has_black_box_text": bool(re.search(r"black[\s_-]?box", text, re.I)),
        "has_compare_points": bool(re.search(r"compare point", text, re.I)),
    }
    json.dump(payload, sys.stdout, indent=2)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
