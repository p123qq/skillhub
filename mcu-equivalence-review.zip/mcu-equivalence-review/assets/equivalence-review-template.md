# Equivalence Review: [Design Name]

## Compared views

State the exact files used for each view:
- **Reference**: RTL filelist path (e.g., `rtl/filelist.f`)
- **Implementation**: synthesis netlist path (e.g., `output/syn/mcu_top_syn.v`)
- **Guidance**: SVF path (e.g., `output/syn/mcu_top.svf`) or "N/A (Genus flow)"
- **Tool**: Formality or Conformal, with version

## Compare-point posture

| Metric | Value |
|--------|-------|
| Total compare points | N |
| Matched | N |
| Unmatched | N |
| Status | PASS / FAIL / INCONCLUSIVE |

If FAIL: do the failures cluster in one hierarchy, or are they scattered?

## SVF and black-box review

- Is the SVF from the same synthesis run as the netlist?
- Is the black-box list identical in both reference and implementation?
- Are there any boundary port mismatches?

Rate: **Clean** / **Has issues** / **Blocker**

## Likely cause of mismatch

If FAIL or INCONCLUSIVE, classify the root cause:
- Setup issue (stale SVF, wrong black-box list, library mismatch)
- Synthesis issue (optimization transformed logic differently than expected)
- RTL issue (design bug visible only after synthesis)

## Recommended next step

One concrete action:
- If setup issue: fix setup and rerun
- If synthesis issue: roll back to synthesis stage
- If RTL issue: route to RTL development
- If PASS: proceed to PnR
