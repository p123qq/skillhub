## Compared views

- Reference: `rtl/filelist.f`
- Implementation: `output/syn/mcu_top_syn.v`
- Guidance: `output/syn/mcu_top.svf`

## Compare-point posture

- most points matched
- failures cluster at one protected-IP boundary
- status is `INCONCLUSIVE`, not broad logical mismatch

## SVF and black-box review

- SVF appears to be from the correct synthesis run
- black-box list is missing one wrapper-level protected module

## Likely cause of mismatch

Boundary inconsistency, not a broad RTL-versus-netlist logic difference.

## Recommended next step

Align black-box scope across both views and rerun equivalence before escalating.
