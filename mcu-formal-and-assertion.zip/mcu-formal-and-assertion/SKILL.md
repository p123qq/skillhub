---
name: mcu-formal-and-assertion
description: Plan high-value assertions, generate SVA property code, and support formal verification tool execution for an MCU SoC design. Use when the user needs to turn protocol intent, reset behavior, FSM rules, and safety conditions into SVA properties, or when formal tool results need interpretation.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# MCU Formal And Assertion

Use this skill to plan assertions, generate SVA code, and guide formal verification tool usage.

## Boundaries

The following tasks are out of scope. Inform the user and, if the corresponding skill exists in the project, suggest routing there.

- Do **not** run formal tools directly (tool invocation varies too much by site and license).
- Do **not** modify RTL. Assertion-related RTL fixes feed back to the user or a companion skill. (Companion skill: `mcu-rtl-development`)
- Do **not** replace simulation verification — SVA complements TB, does not replace it.

## Three Modes

### Property Planning

Triggered when: design intent is clear enough to identify high-value checks, but no SVA code exists yet.

### SVA Code Generation

Triggered when: a property plan exists and SVA source files need to be written.

### Formal Result Review

Triggered when: formal tool (VC Formal, JasperGold) has run and results need interpretation.

## Good Outcome

Produce:

- prioritized property groups
- SVA property files (.sv) with assertions and assumptions
- formal-friendly candidates separated from simulation-only checks
- formal tool result interpretation (if results available)
- assumption and constraint audit notes

## Input Artifacts

| Artifact | Source | Required |
|----------|--------|----------|
| `doc/spec.md` | User-provided or from spec planning stage | Yes (protocol rules, reset behavior) |
| RTL source files | User-provided or from RTL development stage | Yes (signal names, FSM states) |
| `eda_env.json` | From EDA env setup if available | For formal tool availability |

## Output Artifacts

| Artifact | Path | Description |
|----------|------|-------------|
| Property plan | `doc/property_plan.md` | Prioritized property groups |
| SVA files | `tb/sva/*.sv` | Assertion and assumption source code |
| SVA bind file | `tb/sva/sva_bind.sv` | Bind assertions to DUT modules |

## Input Validation

### From spec.md (produced by `mcu-spec-architecture-planning`)

| Required section | What to check | Used for |
|---|---|---|
| Peripheral register map | Per-register: name, offset, reset value, access type | Reset property generation |
| Bus protocol | Bus type (AHB/APB), handshake signal names | Protocol assertion generation |
| Reset strategy | Reset signal name, polarity, sync/async | Reset property `disable iff` clause |
| Clock domains | Clock signal names | Property clock references |
| Interrupt map | IRQ trigger conditions, clear mechanism | Interrupt property generation |

### From RTL source files (produced by `mcu-rtl-development`)

| Required | What to check | Used for |
|---|---|---|
| Module hierarchy | Top module and sub-module names exist in rtl/ | Bind file target modules |
| Signal names | Register names (`_q` suffix), FSM state signals | Property signal references |
| Port declarations | Port directions and widths in modules being asserted | SVA module port list |

SVA code must reference actual signal names from RTL — never guess. If signal names are unclear, read the RTL source first.

### From eda_env.json (optional)

| Field | What to check | Used for |
|---|---|---|
| Formal tool availability | Any formal tool in PATH or modules (vc_formal, jaspergold) | Guidance on whether formal execution is possible |

If no formal tool is available, SVA files can still be generated for simulation-based assertion checking (compiled with VCS/Xcelium).

## Workflow — Property Planning

### Step 1: Identify high-value check categories

From spec and RTL, identify properties in priority order:

| Priority | Category | Examples |
|---|---|---|
| P1 | Reset behavior | All registers reach spec-defined reset values |
| P1 | Bus protocol | AHB HREADY/HRESP handshake, no bus hang |
| P1 | Safety | No deadlock in FSM, no simultaneous conflicting outputs |
| P2 | Register access | W1C clears correctly, RO ignores writes |
| P2 | Interrupt | IRQ asserts under correct conditions, clears on W1C |
| P3 | Data integrity | FIFO no overflow/underflow, memory no address collision |
| P3 | Clock gating | Gated clock does not truncate active transaction |

### Step 2: Separate formal-friendly from simulation-only

| Formal-friendly | Simulation-only |
|---|---|
| Safety properties (should never happen) | Performance properties (latency within N cycles) |
| Protocol invariants | Coverage-driven scenarios |
| Reset and initialization | Multi-transaction sequences |
| FSM reachability | Random stimulus response |

### Step 3: Identify assumptions

Assumptions constrain the formal tool's search space. Keep them narrow:

- Input protocol compliance (e.g. AHB master follows spec)
- Clock and reset well-behaved
- Black-box IP outputs within expected range

Flag any assumption that could mask real bugs.

## Workflow — SVA Code Generation

### Step 4: Generate SVA property files

For each property group, generate an SVA file in `tb/sva/`:

**Reset property example:**
```systemverilog
// sva_reset_checks.sv
module sva_reset_checks (
  input logic clk,
  input logic rst_n,
  input logic [31:0] gpio_dir_q,
  input logic [31:0] gpio_out_q
);

  // All GPIO registers reset to 0
  // For async reset: |-> (same cycle) is sufficient since reset takes effect immediately.
  // For sync reset: use |=> (next cycle) since reset requires a clock edge to take effect.
  // This design uses async reset, so |-> is appropriate.
  property p_gpio_dir_reset;
    @(posedge clk) !rst_n |-> (gpio_dir_q == 32'h0);
  endproperty

  property p_gpio_out_reset;
    @(posedge clk) !rst_n |-> (gpio_out_q == 32'h0);
  endproperty

  a_gpio_dir_reset: assert property (p_gpio_dir_reset);
  a_gpio_out_reset: assert property (p_gpio_out_reset);

endmodule
```

**Bus protocol property example:**
```systemverilog
// sva_ahb_protocol.sv
module sva_ahb_protocol (
  input logic HCLK,
  input logic HRESETn,
  input logic HREADY,
  input logic HRESP,
  input logic [1:0] HTRANS
);

  // No error response from this slave when selected.
  // NOTE: This property assumes the testbench does not access unmapped
  // addresses. If the default slave legitimately returns HRESP=1 for
  // unmapped accesses, bind this assertion only to specific slaves,
  // not to the top-level interconnect.
  property p_no_error_response;
    @(posedge HCLK) disable iff (!HRESETn)
    HREADY |-> (HRESP == 1'b0);
  endproperty

  // No bus hang: HREADY must go high within 16 cycles
  property p_no_bus_hang;
    @(posedge HCLK) disable iff (!HRESETn)
    !HREADY |-> ##[1:16] HREADY;
  endproperty

  a_no_error_response: assert property (p_no_error_response);
  a_no_bus_hang: assert property (p_no_bus_hang);

endmodule
```

### Step 5: Generate bind file

```systemverilog
// sva_bind.sv — bind assertions to DUT modules
bind gpio_ctrl sva_reset_checks u_sva_reset (
  .clk(clk), .rst_n(rst_n),
  .gpio_dir_q(gpio_dir_q), .gpio_out_q(gpio_out_q)
);

bind mcu_top sva_ahb_protocol u_sva_ahb (
  .HCLK(HCLK), .HRESETn(HRESETn),
  .HREADY(HREADY), .HRESP(HRESP), .HTRANS(HTRANS)
);
```

### Step 6: Integration with simulation

SVA files can be compiled alongside RTL and TB for simulation-based assertion checking. Add to `sim/filelist_sim.f`:

```
tb/sva/sva_reset_checks.sv
tb/sva/sva_ahb_protocol.sv
tb/sva/sva_bind.sv
```

## Workflow — Formal Result Review

If a formal tool (VC Formal, JasperGold) has been run:

### Step 7: Interpret results

| Result | Meaning | Action |
|---|---|---|
| Proven | Property holds for all reachable states | Confidence high |
| Falsified | Counterexample found | Debug using the trace |
| Bounded | Proven up to N cycles, not exhaustive | May be acceptable for deep properties |
| Inconclusive | Could not prove or disprove | Check assumptions, increase depth, or simplify |

### Step 8: Audit assumptions

If a property is "proven" but assumptions are too broad, the proof may be vacuously true. Check:
- Are assumptions reachable in real operation?
- Do assumptions exclude valid input scenarios?
- Would removing an assumption cause the property to fail?

## Assertion Quality Rules

### Property priority order

1. Reset safety and post-reset legality — all registers reach spec-defined values
2. Bus protocol correctness — handshake, no bus hang, valid response
3. Interrupt correctness — asserts under right conditions, clears properly
4. Illegal-state prevention — no deadlock in FSM, no simultaneous conflicting outputs
5. Configuration side effects — mode changes do not corrupt in-flight transactions

### Assumption boundaries

- Do not assume away backpressure or error responses unless the environment contract requires it
- Do not force unreachable reset sequences just to close proofs
- Mark assumptions that make the property vacuous or uninteresting
- Every assumption should be justifiable by the spec — if you can't point to a spec clause, the assumption is suspect

### Formal result failure patterns

When formal tools (VC Formal, JasperGold) report failures, common root causes include:

| Pattern | Likely cause | Action |
|---------|-------------|--------|
| Property falsified with short trace | Real RTL bug or overly weak assumption | Debug the counterexample trace |
| Property inconclusive after max depth | State space too large for bounded proof | Simplify property, add cone-of-influence reduction, or accept bounded result |
| All properties proven but assumptions are broad | Possibly vacuous proof | Audit assumptions — remove one at a time and re-run |
| Property proven only with unrealistic reset constraint | Reset assumption masks a real reset-exit bug | Check if the constrained reset sequence matches actual hardware behavior |
| Counterexample involves black-box IP outputs | Proof scope does not constrain IP behavior | Add IP output assumptions from IP datasheet, or exclude IP from proof scope |

## Bundled References

- [black-box-ip-rules.md](references/black-box-ip-rules.md) — IP outside proof scope

## Bundled Assets

- [property-plan-template.md](assets/property-plan-template.md) — property plan output format
- [example-property-review.md](assets/example-property-review.md) — sample property review output
- [sample-property-plan.json](assets/sample-property-plan.json) — structured property plan example

## Completion Gate

Property planning: priorities explicit, formal vs sim-only separated, assumptions listed.

SVA generation: SVA files written in `tb/sva/`, bind file created, can compile with RTL.

Formal review: results interpreted, assumptions audited, follow-up actions identified.

## Decision Rules

- Favor properties that protect architecture intent and reset safety first.
- Keep assumptions narrow and auditable.
- Mark any proof that depends on unrealistic environment behavior.
- SVA property code must use signal names from actual RTL (read RTL source, not guess).
- Reset properties: async reset uses `!rst_n |-> (signal == reset_value)`, sync reset uses `!rst_n |-> ##1 (signal == reset_value)`.
- Protocol properties use `disable iff (!HRESETn)` to exclude reset period.
