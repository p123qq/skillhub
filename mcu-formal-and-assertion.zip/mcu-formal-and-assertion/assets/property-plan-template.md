# Property Plan: [Design Name]

## Intent sources

List the spec sections and architecture notes used to derive properties:
- Bus protocol definition (AHB-Lite handshake rules)
- Reset sequencing notes (which registers reset to what)
- Interrupt behavior summary (trigger conditions, clear mechanism)
- Peripheral-specific control register semantics

## Priority property groups

Numbered list following the priority order from SKILL.md:
1. Reset safety — list specific registers and their expected reset values
2. Bus protocol — list specific handshake properties (no hang, valid response)
3. Interrupt correctness — list per-IRQ assertion/clear properties
4. FSM safety — list illegal states or deadlock conditions
5. Configuration side effects — list mode-change invariants

For each group, note how many properties are planned.

## Formal-friendly candidates

List properties suitable for exhaustive formal proof (safety, invariants, reachability). For each:
- Property name
- What it checks (one sentence)
- Why it is formal-friendly (bounded state space, no deep sequential dependency)

## Simulation-only candidates

List properties that are better checked via simulation (performance, long sequences, coverage-driven). Explain why formal is not practical for each.

## Assumptions and constraints

List every assumption that will be applied to the formal environment. For each:
- What it constrains
- Why it is justified (reference spec clause or interface contract)
- Risk if wrong (what bug could it mask?)

## Manual-review triggers

List conditions under which the property plan should be reviewed by a human before proceeding:
- Any proof that only closes after forbidding real backpressure
- Any property whose meaning changes across a black-box IP boundary
- Any assumption that cannot be traced to a spec clause
