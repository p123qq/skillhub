## Intent sources

- bus protocol note
- reset sequencing note
- interrupt behavior summary
- timer control register semantics

## Priority property groups

1. reset release legality
2. bus response correctness
3. interrupt assertion and clear behavior
4. timer enable and rollover side effects

## Formal-friendly candidates

- no bus response without valid selection
- interrupt must clear after acknowledged clear sequence
- reset exits into one legal state set

## Assumptions and constraints

- one transaction source at a time on the peripheral bus
- external debug path remains inactive in this proof scope
- asynchronous reset is allowed to assert at any time but deasserts cleanly

## Manual-review triggers

- any proof that only closes after forbidding real backpressure
- any property whose meaning changes across the black-box CPU boundary
