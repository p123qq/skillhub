# Black Box IP Rules

When the design contains protected CPU or third-party IP:

- keep the black-box list explicit and reviewable
- make sure reference and implementation use the same black-box boundary
- treat boundary-port mismatches as first-class blockers
- do not claim equivalence inside the IP when the proof scope excludes it

This is especially important for Cortex-M3 cores, SRAM macros, and encrypted vendor blocks.
