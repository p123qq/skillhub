# Engineering Thresholds

Use these bands to decide whether physical implementation is noisy, stressed, or structurally unhealthy.

## Congestion

- local hotspot with manageable overflow: investigate placement and routing detail
- repeated hotspot around macros or bus/control cluster: treat as topology issue
- broad overflow across the same region after rerun: prefer rollback over more blind route attempts

## Utilization

- roughly `65%` to `75%`: typical workable review band for this bundle
- above that band with congestion: treat utilization as a likely contributor

## Clocking

- skew within project target and stable across reruns: likely local-closure territory
- unstable skew combined with placement stress: likely structural clock-topology issue
