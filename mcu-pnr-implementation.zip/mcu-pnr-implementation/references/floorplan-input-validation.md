# Floorplan Input Validation

Before diagnosing physical failure, validate that implementation is starting from a coherent input set:

- synthesized netlist exists and matches the expected top module
- macro inventory is known and placement assumptions are explicit
- die size and utilization target are plausible together
- pin intent and major I/O groupings are not contradictory
- power-intent assumptions are present before grid planning

If one of these is missing, stop calling the result a PnR closure problem.
