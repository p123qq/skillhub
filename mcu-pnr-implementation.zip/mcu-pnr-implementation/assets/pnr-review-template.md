# PnR Review: [Design Name]

## Reviewed evidence

List all reports and logs examined:
- Floorplan check report
- Post-placement timing/congestion
- Post-CTS skew report
- Post-route timing report
- DRC check report
- Connectivity check report

Note any reports that are missing or stale.

## Main physical blockers

| Issue | Location | Severity | Evidence |
|-------|----------|----------|----------|
| Congestion overflow | area/region | Blocker/Warning | from congestion report |
| Timing violation | path description | WNS value | from timing report |
| DRC violations | count | Blocker if > 0 | from DRC report |
| ... | ... | ... | ... |

## Likely upstream causes

For each blocker, classify whether it is:
- **Physical-only**: fixable by PnR iteration (placement tweak, route retry)
- **Synthesis-driven**: needs constraint or effort change upstream
- **Architecture-driven**: needs RTL or floorplan restructuring

## Ranked closure priorities

Numbered list of actions in priority order:
1. What to fix first and why
2. What to fix next
3. What can wait

## Signoff readiness or rollback

- **Ready for signoff**: if timing met, 0 DRC, GDS exported
- **Iterate PnR**: if issues are local and fixable
- **Roll back to synthesis**: if constraints or effort are the root cause
- **Roll back to RTL**: if architecture-level pressure dominates
