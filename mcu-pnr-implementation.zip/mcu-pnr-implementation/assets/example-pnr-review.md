## Reviewed evidence

- floorplan snapshot with SRAM macros
- congestion summary around APB bridge and memory edge
- post-CTS skew summary
- post-route timing summary

## Main physical blockers

- routing congestion at the channel between SRAM and bus/control cluster
- one setup-critical path that crosses a long macro-to-logic route

## Likely upstream causes

- macro channel is too narrow for current interconnect density
- control hierarchy keeps too much arbitration logic on one side of the floorplan

## Ranked closure priorities

1. adjust macro spacing and local channel width
2. reassess placement of the bus/control cluster
3. rerun only after physical topology is cleaner

## Signoff readiness or rollback

Not signoff-ready. If congestion remains after one clean floorplan adjustment, roll back to `mcu-synthesis-planning` or `mcu-rtl-development` to reassess structure.
