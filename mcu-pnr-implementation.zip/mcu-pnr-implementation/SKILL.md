---
name: mcu-pnr-implementation
description: Run floorplanning, place and route (Innovus; ICC2 flow supported but templates not bundled), and GDS export for an MCU SoC design. Generates execution scripts from templates, invokes PnR tools, parses results, and reviews implementation risks. Use when a synthesis netlist is ready for physical implementation, or when PnR reports need interpretation.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# MCU PnR Implementation

Use this skill to run physical implementation and review results. Covers MMMC setup, floorplan, placement, CTS, routing, filler insertion, GDS export, and QoR analysis.

## Boundaries

The following tasks are out of scope. Inform the user and, if the corresponding skill exists in the project, suggest routing there.

- Do **not** modify RTL or synthesis netlist. Optimization feeds back upstream. (Companion skills: `mcu-rtl-development`, `mcu-synthesis-planning`)
- Do **not** run signoff tools (STA, extraction, DRC, LVS). (Companion skill: `mcu-signoff-review`)
- Do **not** run equivalence checking. (Companion skill: `mcu-equivalence-review`)

## Good Outcome

Produce:

- MMMC view file and floorplan/PnR scripts generated from templates
- floorplanned and routed design with timing closure
- post-route netlist, DEF, SDC, and GDS
- implementation reports (timing, area, power, congestion, DRC)
- risk assessment with closure priorities

## Input Artifacts

| Artifact | Source | Required |
|----------|--------|----------|
| `eda_env.json` | From EDA env setup if available | Yes |
| `doc/spec.md` | User-provided or from spec planning stage | Yes (die size, macro info) |
| Synthesis netlist | From synthesis stage | Yes |
| Synthesis SDC | From synthesis stage | Yes |
| Equivalence PASS | From equivalence stage if available | Recommended |

## Output Artifacts

| Artifact | Path | Description |
|----------|------|-------------|
| MMMC view | `scripts/mmmc.view` | Generated MMMC setup |
| Floorplan script | `scripts/innovus_fp.tcl` | Generated from template |
| PnR script | `scripts/innovus_pnr.tcl` | Generated from template |
| GDS script | `scripts/innovus_gds.tcl` | Generated from template |
| Post-route netlist | `output/pnr/<design>_final.v` | Gate-level after routing |
| Post-route DEF | `output/pnr/<design>_final.def` | Physical layout |
| Post-route SDC | `output/pnr/<design>_final.sdc` | Propagated constraints |
| GDS | `output/gds/<design>.gds` | Layout for signoff |
| Reports | `rpt/pnr_timing.rpt`, `pnr_area.rpt`, `pnr_power.rpt`, etc. | PnR QoR reports |

## Input Validation

### From eda_env.json

| Required field | What to check | Used for |
|---|---|---|
| `selected_tools.pnr` | Not null, one of: innovus, icc2. Bundled templates cover Innovus only; ICC2 requires user-supplied scripts | Template and command selection |
| `pdk.tech_lef` or `pdk.tech_file` | Path exists | Technology for init_design |
| `libraries.std_cell.ss.lib` | At least SS corner .lib files | MMMC setup timing |
| `libraries.std_cell.ff.lib` | At least FF corner .lib files | MMMC hold corner |
| `pdk.tlu_plus_max` or `pdk.qrc_tech_max` | Path exists (TLU+ or QRC techfile) | RC corner worst. Note: some PDKs have TLU+ syntax errors (IMPEXT-2715) — use QRC techfile as alternative |
| `pdk.tlu_plus_min` or `pdk.qrc_tech_min` | Path exists (TLU+ or QRC techfile) | RC corner best |

### From synthesis outputs

| Required | What to check | Used for |
|---|---|---|
| `output/syn/<design>_syn.v` | Exists | Design netlist for init |
| `output/syn/<design>_syn.sdc` | Exists | Constraint mode |

## Workflow

### Step 1: Generate MMMC view

Read `scripts/innovus_mmmc_template.view`, fill placeholders:

| Placeholder | Value source |
|---|---|
| `{{SS_LIB_FILES}}` | eda_env.json → libraries.std_cell.ss.lib |
| `{{FF_LIB_FILES}}` | eda_env.json → libraries.std_cell.ff.lib |
| `{{TLU_PLUS_MAX}}` | eda_env.json → pdk.tlu_plus_max |
| `{{TLU_PLUS_MIN}}` | eda_env.json → pdk.tlu_plus_min |
| `{{SDC_FILES}}` | `output/syn/<design>_syn.sdc` |

Write to `scripts/mmmc.view`.

### Step 2: Generate floorplan script

Read `scripts/innovus_fp_template.tcl`, fill placeholders:

| Placeholder | Value source |
|---|---|
| `{{LEF_FILE_LIST}}` | eda_env.json → tech_lef + cell LEF + macro LEF |
| `{{SYN_NETLIST}}` | `output/syn/<design>_syn.v` |
| `{{TOP_MODULE}}` | spec.md → top module |
| `{{MMMC_FILE}}` | `scripts/mmmc.view` |
| `{{DIE_WIDTH}}` / `{{DIE_HEIGHT}}` | spec.md → die dimensions |
| `{{TAP_CELL}}`, `{{ENDCAP_LEFT}}`, `{{ENDCAP_RIGHT}}` | eda_env.json → physical_cells |
| `{{MACRO_PLACEMENT_CMDS}}` | Project-specific SRAM placement (from spec macro info) |
| `{{RING_H_LAYER}}`, `{{RING_V_LAYER}}` etc. | PDK metal stack (from tech file or user) |

Write to `scripts/innovus_fp.tcl`.

### Step 3: Execute floorplan

```
innovus -batch -files scripts/innovus_fp.tcl -log rpt/innovus_fp 2>&1 | tee rpt/innovus_fp.log
```

Check for `INNOVUS_FLOORPLAN_COMPLETE` in log. If LSF available, submit via `bsub`.

### Step 4: Generate PnR script

Read `scripts/innovus_pnr_template.tcl`, fill placeholders:

| Placeholder | Value source |
|---|---|
| `{{DB_DIR}}` | `output/innovus` |
| `{{FILLER_CELLS}}` | eda_env.json → physical_cells.filler |
| `{{BLACK_BOX_CTS_CMDS}}` | Per black-box: `set_db [get_db insts -if {.base_cell.name == <module>}] .dont_touch true` |
| `{{RPT_DIR}}`, `{{OUTPUT_DIR}}` | Project paths |

Write to `scripts/innovus_pnr.tcl`.

### Step 5: Execute PnR

```
innovus -batch -files scripts/innovus_pnr.tcl -log rpt/innovus_pnr 2>&1 | tee rpt/innovus_pnr.log
```

Check for `INNOVUS_PNR_COMPLETE`.

### Step 6: Parse results

Extract from reports:

| Metric | Source | Pass criteria |
|---|---|---|
| WNS (setup) | `rpt/pnr_timing.rpt` | >= 0 ns |
| WHS (hold) | `rpt/pnr_hold_timing.rpt` | >= 0 ns |
| Utilization | `rpt/pnr_area.rpt` | 65-75% typical |
| Congestion overflow | `rpt/pnr_congestion.rpt` | 0 |
| DRC | `rpt/pnr_check_drc.rpt` | 0 violations |

### Step 7: GDS export (conditional)

Only if PnR passes QoR checks. Read `scripts/innovus_gds_template.tcl`, fill placeholders:

| Placeholder | Value source |
|---|---|
| `{{DB_DIR}}` | `output/innovus` |
| `{{GDS_DIR}}` | `output/gds` |
| `{{DESIGN}}` | spec.md → design name |
| `{{TOP_MODULE}}` | spec.md → top module |
| `{{LAYER_MAP}}` | eda_env.json → pdk.layer_map |
| `{{MERGE_GDS_FILES}}` | eda_env.json → std cell GDS + macro GDS file paths |

Write to `scripts/innovus_gds.tcl`. Execute:

```
innovus -batch -files scripts/innovus_gds.tcl -log rpt/innovus_gds 2>&1 | tee rpt/innovus_gds.log
```

### Step 8: Route result

| Result | Route to | Action |
|---|---|---|
| Timing met, 0 DRC, GDS exported | `mcu-signoff-review` | Proceed to signoff |
| WNS < 0 (small) | Retry with `optDesign -postRoute` | Iterate |
| WNS < 0 (large) or congestion | `mcu-synthesis-planning` | May need constraint or RTL change |
| Floorplan issues | Adjust macro placement, die size | Iterate floorplan step |

## PnR Quality Rules

### Implementation hotspot patterns

- Macro placement creates routing choke points — channel width often matters more than route retries
- Clock root choices amplify skew or buffering pressure
- Reset or control networks create unexpected fanout stress near macros
- Power planning assumptions conflict with placement reality
- Bus and control logic adjacent to macros can create repeated localized congestion overflow

### Rollback signals

Roll back to an upstream stage when:
- Severe timing spread is caused by unrealistic synthesis constraints — fix constraints first
- Congestion is caused by architecture-level hierarchy or floorplan assumptions — adjust floorplan or RTL
- Repeated CTS instability is tied to unresolved clock intent — clarify clock architecture

### Black-box and macro handling

- Treat SRAM macros and protected IP as placement-shaping objects, not ordinary logic
- Keep `dont_touch` intent explicit for blocks that should not be reshaped by optimization
- Watch for routing choke points and skew pressure around macro channels
- If macro placement dominates critical paths, prefer floorplan adjustment before broad route retries
- Long control paths around macros often show up later as signoff timing surprises

## Bundled References

- [floorplan-input-validation.md](references/floorplan-input-validation.md) — input completeness
- [engineering-thresholds.md](references/engineering-thresholds.md) — utilization and congestion bands

## Bundled Assets

- [pnr-review-template.md](assets/pnr-review-template.md) — PnR review output format
- [example-pnr-review.md](assets/example-pnr-review.md) — sample PnR review output
- [sample-pnr-hotspots.json](assets/sample-pnr-hotspots.json) — structured hotspot example

## Bundled Scripts

- [innovus_fp_template.tcl](scripts/innovus_fp_template.tcl) — floorplan template (verified against MCP server)
- [innovus_pnr_template.tcl](scripts/innovus_pnr_template.tcl) — P&R template (verified against MCP server)
- [innovus_gds_template.tcl](scripts/innovus_gds_template.tcl) — GDS export template
- [innovus_mmmc_template.view](scripts/innovus_mmmc_template.view) — MMMC view template
- [parse_congestion_summary.py](scripts/parse_congestion_summary.py) — congestion report parser

> **Note:** All script templates above target Innovus. ICC2 is a supported PnR option, but equivalent ICC2 templates are not bundled. If `selected_tools.pnr` is `icc2`, the user must supply equivalent TCL scripts.

## Completion Gate

- MMMC view and all scripts generated from templates with project-specific values
- Floorplan executed, database saved
- PnR executed, timing/area/power/congestion/DRC reports generated
- Post-route netlist, DEF, SDC exported
- GDS exported (if QoR passes)
- QoR assessed with next-step routing

## Decision Rules

- Do not treat repeated congestion symptoms as isolated local noise.
- Call out upstream causes early when placement trouble is structural.
- If utilization > 80%, flag as high risk — may need die size increase or RTL optimization.
- Back up previous PnR outputs before re-running.
