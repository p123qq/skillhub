# {{GENERATED_BY}}
# Cadence Innovus GDS Export Script
# Design: {{DESIGN}}

restoreDesign {{DB_DIR}}/pnr_db.dat

set streamOutMode -specifyViaName default
streamOut {{GDS_DIR}}/{{DESIGN}}.gds \
    -mapFile {{LAYER_MAP}} \
    -libName {{DESIGN}} \
    -structureName {{TOP_MODULE}} \
    -merge {{{MERGE_GDS_FILES}}} \
    -stripes 1 \
    -units 1000

puts "INNOVUS_GDS_EXPORT_COMPLETE"
exit
