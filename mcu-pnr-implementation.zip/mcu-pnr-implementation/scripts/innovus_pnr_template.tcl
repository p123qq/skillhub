# {{GENERATED_BY}}
# Innovus Place & Route Script — generated from innovus_pnr_template.tcl
# Design: {{DESIGN}}
# Do not edit manually — regenerate via mcu-pnr-implementation skill
# Verified against MCP server innovus.mjs

set PROJ_HOME "{{PROJ_HOME}}"

#-------------------------------------------------------------------------------
# Restore Floorplanned Design
#-------------------------------------------------------------------------------
source {{DB_DIR}}/fp_db

#-------------------------------------------------------------------------------
# Placement
#-------------------------------------------------------------------------------
puts "INFO: Starting placement..."
set_db place_detail_legalization_inst_gap 1
place_opt_design

report_timing -max_paths 5 > {{RPT_DIR}}/pnr_post_place_timing.rpt
reportCongestion > {{RPT_DIR}}/pnr_post_place_congestion.rpt

#-------------------------------------------------------------------------------
# Clock Tree Synthesis
#-------------------------------------------------------------------------------
puts "INFO: Starting clock tree synthesis..."
set_db cts_target_max_transition_time 0.15
set_db cts_target_skew 0.1

# Exclude black box instances from CTS
{{BLACK_BOX_CTS_CMDS}}

set_ccopt_property update_io_latency false
create_ccopt_clock_tree_spec
set_ccopt_property target_max_trans 0.15
set_ccopt_property target_skew 0.1

catch {clock_opt_design} cts_err
if {$cts_err ne ""} {
  puts "WARNING: CTS completed with issues: $cts_err"
  puts "INFO: Continuing with routing..."
}

report_clock_timing -type skew > {{RPT_DIR}}/pnr_clock_skew.rpt
report_timing -max_paths 5 > {{RPT_DIR}}/pnr_post_cts_timing.rpt

#-------------------------------------------------------------------------------
# Routing
#-------------------------------------------------------------------------------
puts "INFO: Starting routing..."
set_db route_design_with_timing_driven true
set_db route_design_with_si_driven true
routeDesign -globalDetail

report_timing -max_paths 5 > {{RPT_DIR}}/pnr_post_route_timing.rpt

#-------------------------------------------------------------------------------
# Post-Route Optimization
#-------------------------------------------------------------------------------
puts "INFO: Starting post-route optimization..."
set_db timing_analysis_type ocv
catch {optDesign -postRoute -setup -hold} opt_err
if {$opt_err ne ""} {
  puts "WARNING: Post-route optimization had issues: $opt_err"
  puts "INFO: Continuing with filler insertion..."
}

#-------------------------------------------------------------------------------
# Filler Cells
#-------------------------------------------------------------------------------
puts "INFO: Inserting filler cells..."
addFiller -cell {{{FILLER_CELLS}}} -prefix FILLER
checkFiller

#-------------------------------------------------------------------------------
# Final Reports
#-------------------------------------------------------------------------------
report_timing -max_paths 10 > {{RPT_DIR}}/pnr_timing.rpt
report_timing -early -max_paths 10 > {{RPT_DIR}}/pnr_hold_timing.rpt
report_area > {{RPT_DIR}}/pnr_area.rpt
report_power > {{RPT_DIR}}/pnr_power.rpt
reportCongestion > {{RPT_DIR}}/pnr_congestion.rpt
report_design > {{RPT_DIR}}/pnr_design_summary.rpt

# DRC checks
verify_drc > {{RPT_DIR}}/pnr_check_drc.rpt
verifyConnectivity > {{RPT_DIR}}/pnr_check_conn.rpt

#-------------------------------------------------------------------------------
# Export Deliverables
#-------------------------------------------------------------------------------
saveNetlist {{OUTPUT_DIR}}/{{DESIGN}}_final.v
write_sdc {{OUTPUT_DIR}}/{{DESIGN}}_final.sdc
defOut -floorplan -netlist -routing {{OUTPUT_DIR}}/{{DESIGN}}_final.def

#-------------------------------------------------------------------------------
# Save Design
#-------------------------------------------------------------------------------
saveDesign {{DB_DIR}}/pnr_db

puts "INNOVUS_PNR_COMPLETE"
exit
