import json
import re
import sys


def extract(pattern: str, text: str):
    match = re.search(pattern, text, re.I)
    return float(match.group(1)) if match else None


def main() -> int:
    text = sys.stdin.read()
    payload = {
        "wns_ns": extract(r"WNS[^-0-9]*(-?\d+(?:\.\d+)?)", text),
        "whs_ns": extract(r"WHS[^-0-9]*(-?\d+(?:\.\d+)?)", text),
        "tns_ns": extract(r"TNS[^-0-9]*(-?\d+(?:\.\d+)?)", text),
    }
    json.dump(payload, sys.stdout, indent=2)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
