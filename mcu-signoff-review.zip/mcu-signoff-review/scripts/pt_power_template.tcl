# {{GENERATED_BY}}
# PrimeTime Power Analysis Script
# Design: {{DESIGN}}

#--------------------------------------------------------------
# Library Setup
#--------------------------------------------------------------
set search_path  "{{SEARCH_PATH}}"
set target_library "{{TARGET_LIBRARY}}"
set link_library   "* {{LINK_LIBRARY}}"

#--------------------------------------------------------------
# Read Design (same style as pt_sta_template.tcl)
#--------------------------------------------------------------
set_app_var link_create_black_boxes true
read_verilog {{NETLIST}}
current_design {{TOP_MODULE}}
link

#--------------------------------------------------------------
# Parasitics (optional)
#--------------------------------------------------------------
# read_parasitics -format spef {{SPEF_PATH}}

#--------------------------------------------------------------
# Constraints
#--------------------------------------------------------------
source {{SDC_PATH}}

#--------------------------------------------------------------
# Activity
#--------------------------------------------------------------
# If SAIF/VCD available:
# read_saif {{SAIF_PATH}}
# Otherwise use default toggle:
set_switching_activity -toggle_rate 0.1 -static_probability 0.5 [all_nets]

#--------------------------------------------------------------
# Power Analysis
#--------------------------------------------------------------
report_power > {{RPT_DIR}}/pt_power.rpt
report_power -hierarchy > {{RPT_DIR}}/pt_power_hier.rpt

set total_power [get_attribute [current_design] total_power]
set dyn_power   [get_attribute [current_design] dynamic_power]
set leak_power  [get_attribute [current_design] leakage_power]
puts "POWER_TOTAL_MW:[expr $total_power * 1000]"
puts "POWER_DYNAMIC_MW:[expr $dyn_power * 1000]"
puts "POWER_LEAKAGE_MW:[expr $leak_power * 1000]"

puts "PT_POWER_COMPLETE"
exit
