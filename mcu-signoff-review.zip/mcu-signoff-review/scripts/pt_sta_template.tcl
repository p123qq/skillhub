# {{GENERATED_BY}}
# PrimeTime Static Timing Analysis Script — generated from pt_sta_template.tcl
# Design: {{DESIGN}}
# Do not edit manually — regenerate via mcu-signoff-review skill
# Verified against MCP server primetime.mjs

set PROJ_HOME "{{PROJ_HOME}}"

#-------------------------------------------------------------------------------
# Library Setup
#-------------------------------------------------------------------------------
set search_path [list \
{{SEARCH_PATH_LIST}}
]

set link_library [list "*" \
{{LINK_LIBRARY_LIST}}
]

#-------------------------------------------------------------------------------
# Read Design
#-------------------------------------------------------------------------------
set_app_var link_create_black_boxes true
read_verilog {{NETLIST}}
current_design {{TOP_MODULE}}
link

#-------------------------------------------------------------------------------
# Read Parasitics
#-------------------------------------------------------------------------------
read_parasitics -format spef {{SPEF_PATH}}

#-------------------------------------------------------------------------------
# Apply Constraints
#-------------------------------------------------------------------------------
source {{SDC_PATH}}

#-------------------------------------------------------------------------------
# Update Timing
#-------------------------------------------------------------------------------
update_timing -full

#-------------------------------------------------------------------------------
# Reports
#-------------------------------------------------------------------------------
# Setup timing (max delay)
report_timing -max_paths 50 -slack_lesser_than 0 > {{RPT_DIR}}/pt_timing_setup.rpt
report_timing -max_paths 10 > {{RPT_DIR}}/pt_timing_setup_all.rpt

# Hold timing (min delay)
report_timing -delay_type min -max_paths 50 -slack_lesser_than 0 > {{RPT_DIR}}/pt_timing_hold.rpt

# Constraint violations
report_constraint -all_violators > {{RPT_DIR}}/pt_violations.rpt

# Timing checks
check_timing > {{RPT_DIR}}/pt_check_timing.rpt

# QoR
report_qor > {{RPT_DIR}}/pt_qor.rpt

#-------------------------------------------------------------------------------
# Extract Key Metrics
#-------------------------------------------------------------------------------
set wns_path [get_timing_paths -max_paths 1]
set wns [get_attribute $wns_path slack]
puts "SETUP_WNS:$wns"

set whs_path [get_timing_paths -max_paths 1 -delay_type min]
set whs [get_attribute $whs_path slack]
puts "HOLD_WHS:$whs"

puts "PT_STA_COMPLETE"
exit
