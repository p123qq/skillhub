## Reviewed signoff evidence

- `output/starrc/mcu_top_cworst.spef`
- `rpt/pt_timing_setup.rpt`
- `rpt/pt_timing_hold.rpt`
- `rpt/pt_power.rpt`
- `output/pv/drc_summary.rpt`
- `output/pv/lvs_report.rpt`

## Confirmed blockers

- setup WNS remains negative on one inter-block path
- STA run used a newer netlist revision than the currently reviewed LVS snapshot

## Non-blockers

- hold timing is clean
- DRC count is zero
- LVS is clean for the reviewed snapshot

## Continue, pause, or rollback

- Pause signoff closure until report revision consistency is restored
- If the negative setup path remains after consistent rerun, roll back to `mcu-pnr-implementation`

## Highest-priority fix area

- align netlist, DEF, SDC, and extracted views to one coherent revision
- then re-evaluate the top setup path
