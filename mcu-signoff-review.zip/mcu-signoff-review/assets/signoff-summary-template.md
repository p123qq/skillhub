# Signoff Review: [Design Name]

## Reviewed signoff evidence

List each signoff check and its evidence source:

| Check | Report file | Status | Key metric |
|-------|-------------|--------|------------|
| Extraction | SPEF path | exists/missing | corner |
| STA setup | pt_timing_setup.rpt | WNS value | violation count |
| STA hold | pt_timing_hold.rpt | WHS value | violation count |
| Power | pt_power.rpt | total mW | vs budget |
| DRC | drc_summary.rpt | violation count | 0 = clean |
| LVS | lvs_results.rpt | CORRECT/INCORRECT | |

Note any checks that were not run or whose inputs are stale.

## Confirmed blockers

List each issue that prevents tapeout. For each:
- Which check failed
- What the failure is (WNS value, DRC count, LVS mismatch)
- Whether it is fixable at signoff level or requires upstream rollback

## Non-blockers

List issues that are present but do not prevent tapeout (warnings, density advisories, minor DRC waivers with justification).

## Continue, pause, or rollback

State the recommended action:
- **Continue to handoff**: all checks pass, design is tapeout-ready
- **Pause**: one check is marginal, needs focused investigation
- **Rollback to PnR**: physical issues (DRC, routing, placement)
- **Rollback to synthesis**: constraint or QoR issues
- **Rollback to RTL**: architecture-level power or timing pressure

## Highest-priority fix area

One sentence: what is the single most impactful thing to fix before the next signoff attempt?
