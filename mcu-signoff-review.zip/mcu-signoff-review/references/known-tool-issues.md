# Known Tool Issues

## PrimeTime

- **PrimeTime V-2023.12-SP1 on Rocky Linux 8.10**: Known segfault caused by NSS_Init crash. If `pt_shell` crashes on startup before executing any TCL, this is an OS/tool compatibility issue, not a design problem. Workarounds: try a different PT version, run on a different OS, or use Cadence Tempus as an alternative STA tool.
