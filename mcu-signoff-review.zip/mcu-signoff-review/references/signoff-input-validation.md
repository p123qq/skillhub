# Signoff Input Validation

Validate input integrity before interpreting signoff results:

- netlist, DEF, SDC, and extracted views come from compatible revisions
- required rule decks and technology files are present
- chosen corners are explicit and not silently substituted
- the expected GDS export evidence exists before DRC/LVS claims are trusted

Missing input integrity should be reported as a blocker immediately, not as a mysterious tool failure.
