# Engineering Thresholds

Use these thresholds as practical signoff review guidance.

## Timing

- setup and hold both clean: timing evidence is signoff-capable
- one marginal violation with otherwise consistent evidence: pause and classify carefully
- repeated negative setup after aligned reruns: roll back to implementation or synthesis review

## Physical

- DRC `0` and LVS `CORRECT`: physical signoff evidence is clean
- clean DRC/LVS with stale timing context: not signoff-ready

## Power

- within target: acceptable
- over target with stale extraction or stale activity context: fix evidence first
- over target with aligned evidence: treat as a real blocker
