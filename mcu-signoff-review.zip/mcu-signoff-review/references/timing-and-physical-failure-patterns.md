# Timing And Physical Failure Patterns

## Extraction-side problems

- missing or incompatible technology files
- broken layout connectivity or missing physical inputs

## STA-side problems

- setup paths dominated by inter-block distance or macro placement
- hold failures that are localized and buffer-fixable
- stale SDC or stale SPEF relative to the netlist

## Physical signoff problems

- DRC driven by density, spacing, or route artifacts
- LVS mismatch caused by stale netlist or export inconsistency

## Decision Rules

- If the blocker is stale input, stop and fix the input set first.
- If setup collapse is structural, prefer rollback to implementation or synthesis over cosmetic retries.
- If DRC/LVS are clean but timing context is stale, the design is not signoff-ready.
