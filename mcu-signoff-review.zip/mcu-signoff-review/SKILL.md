---
name: mcu-signoff-review
description: Run signoff checks (parasitic extraction, STA, power analysis, DRC, LVS) and review results for an MCU SoC design. Generates tool scripts from templates, executes StarRC/PrimeTime/Calibre (Cadence equivalents supported but templates not bundled), parses results, and assesses tapeout readiness. Use when a routed design with GDS exists and needs signoff verification.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# MCU Signoff Review

Use this skill to run the signoff tool chain and assess tapeout readiness. Covers parasitic extraction, static timing analysis, power analysis, physical verification (DRC/LVS), and result review.

## Boundaries

The following tasks are out of scope. Inform the user and, if the corresponding skill exists in the project, suggest routing there.

- Do **not** modify PnR outputs. Fix suggestions feed back to the user. (Companion skill: `mcu-pnr-implementation`)
- Do **not** modify RTL or synthesis. Upstream fixes go through the appropriate stage.
- Do **not** generate the final report. (Companion skill: `mcu-report-and-handoff`)

## Good Outcome

Produce:

- SPEF parasitic file from extraction
- STA reports with setup/hold slack values
- power analysis report with total power vs budget
- DRC report with violation count
- LVS report with CORRECT/INCORRECT status
- signoff readiness assessment: pass, blocker list, or rollback recommendation

## Input Artifacts

| Artifact | Source | Required |
|----------|--------|----------|
| `eda_env.json` | From EDA env setup if available | Yes |
| `doc/spec.md` | User-provided or from spec planning stage | Yes (power budget) |
| Post-route netlist | From PnR stage | Yes |
| Post-route DEF | From PnR stage | Yes |
| Post-route SDC | From PnR stage | Yes |
| GDS | From PnR stage | Yes |

## Output Artifacts

| Artifact | Path | Description |
|----------|------|-------------|
| Extraction script | `scripts/starrc_run.cmd` | Generated StarRC command file |
| STA script | `scripts/pt_sta.tcl` | Generated PrimeTime STA script |
| Power script | `scripts/pt_power.tcl` | Generated PrimeTime power script |
| DRC runset | `scripts/calibre_drc.runset` | Generated Calibre DRC runset |
| LVS runset | `scripts/calibre_lvs.runset` | Generated Calibre LVS runset |
| SPEF | `output/starrc/<design>_<corner>.spef` | Extracted parasitics |
| STA reports | `rpt/pt_timing_setup.rpt`, `rpt/pt_timing_hold.rpt` | Timing results |
| Power report | `rpt/pt_power.rpt` | Power breakdown |
| DRC summary | `rpt/calibre_drc/drc_summary.rpt` | Violation count |
| LVS report | `rpt/calibre_lvs/lvs_results.rpt` | CORRECT/INCORRECT |

## Input Validation

### From eda_env.json

| Required field | What to check | Used for |
|---|---|---|
| `selected_tools.extraction` | Not null (starrc or qrc). Bundled templates cover StarRC only; QRC requires user-supplied scripts | Extraction tool |
| `selected_tools.sta` | Not null (primetime or tempus). Bundled templates cover PrimeTime only; Tempus requires user-supplied scripts | STA tool |
| `selected_tools.physical_ver` | Not null (calibre, icv, or pegasus). Bundled templates cover Calibre only; ICV/Pegasus require user-supplied runsets | DRC/LVS tool |
| `pdk.drc_rules` | Path exists | Calibre DRC rule deck |
| `pdk.lvs_rules` | Path exists | Calibre LVS rule deck |
| `pdk.extraction_tech_dir` | Path exists | StarRC nxtgrd files |

### From PnR outputs

| Required | What to check | Used for |
|---|---|---|
| `output/pnr/<design>_final.v` | Exists | STA netlist, LVS source |
| `output/pnr/<design>_final.def` | Exists | StarRC extraction input |
| `output/pnr/<design>_final.sdc` | Exists | STA constraints |
| `output/gds/<design>.gds` | Exists | DRC/LVS layout, StarRC input |

## Workflow

Signoff tasks can run in parallel where inputs allow:

- **Path A (Timing)**: Extraction → STA → Power (sequential, SPEF needed for STA)
- **Path B (Physical)**: DRC + LVS (parallel, only need GDS + netlist)

### Path A — Timing Signoff

#### Step A1: Parasitic extraction

Read `scripts/starrc_cmd_template.txt`, fill placeholders:

| Placeholder | Value source |
|---|---|
| `{{DESIGN}}` | spec.md → design name |
| `{{DEF_PATH}}` | `output/pnr/<design>_final.def` |
| `{{LEF_FILES}}` | eda_env.json → tech_lef + cell LEF + macro LEF |
| `{{NXTGRD_PATH}}` | eda_env.json → pdk.extraction_tech_dir (corner-specific) |
| `{{LAYER_MAP}}` | eda_env.json → pdk.layer_map |
| `{{TEMPERATURE}}` | 125 for worst case (ss corner) |
| `{{WORK_DIR}}` | StarRC working directory, e.g. `output/starrc/work` |
| `{{OUTPUT_DIR}}` | `output/starrc` |
| `{{CORNER}}` | `cworst` |

Write to `scripts/starrc_run.cmd`. Execute:
```
StarXtract scripts/starrc_run.cmd 2>&1 | tee rpt/starrc_run.log
```

Verify SPEF file exists at `output/starrc/<design>_cworst.spef`.

**Multi-corner note:** The template above covers worst-case (cworst) extraction for setup analysis. Hold analysis requires a best-case (cbest) SPEF — repeat Step A1 with `{{CORNER}}` = `cbest` and `{{TEMPERATURE}}` = -40 (ff corner). If StarRC multi-corner extraction is unavailable, use Innovus built-in QRC extraction as a fallback.

#### Step A2: Static timing analysis

Read `scripts/pt_sta_template.tcl`, fill placeholders:

| Placeholder | Value source |
|---|---|
| `{{NETLIST}}` | `output/pnr/<design>_final.v` |
| `{{TOP_MODULE}}` | spec.md → top module |
| `{{SPEF_PATH}}` | `output/starrc/<design>_cworst.spef` |
| `{{SDC_PATH}}` | `output/pnr/<design>_final.sdc` |
| `{{SEARCH_PATH_LIST}}` | eda_env.json → library search paths |
| `{{LINK_LIBRARY_LIST}}` | eda_env.json → ss corner .db files |
| `{{RPT_DIR}}` | `rpt` |

Write to `scripts/pt_sta.tcl`. Execute:
```
pt_shell -f scripts/pt_sta.tcl -output_log_file rpt/pt_sta.log
```

Parse log for `SETUP_WNS` and `HOLD_WHS` values.

#### Step A3: Power analysis

Read `scripts/pt_power_template.tcl`, fill placeholders:

| Placeholder | Value source |
|---|---|
| `{{SEARCH_PATH}}` | eda_env.json → library search paths (same as STA) |
| `{{TARGET_LIBRARY}}` | eda_env.json → ss corner .db file |
| `{{LINK_LIBRARY}}` | eda_env.json → ss corner .db + SRAM .db files |
| `{{NETLIST}}` | `output/pnr/<design>_final.v` |
| `{{TOP_MODULE}}` | spec.md → top module |
| `{{SDC_PATH}}` | `output/pnr/<design>_final.sdc` |
| `{{RPT_DIR}}` | `rpt` |

Optional (uncomment in template if available):
- `{{SPEF_PATH}}` — SPEF from extraction (improves accuracy)
- `{{SAIF_PATH}}` — switching activity from simulation

Execute:
```
pt_shell -f scripts/pt_power.tcl -output_log_file rpt/pt_power.log
```

Parse log for `POWER_TOTAL_MW`.

### Path B — Physical Verification

#### Step B1: DRC

Read `scripts/calibre_drc_template.runset`, fill placeholders:

| Placeholder | Value source |
|---|---|
| `{{GDS_PATH}}` | `output/gds/<design>.gds` |
| `{{TOP_MODULE}}` | spec.md → top module |
| `{{DRC_RULES_PATH}}` | eda_env.json → pdk.drc_rules |
| `{{RESULTS_DIR}}` | `rpt/calibre_drc` |

Write to `scripts/calibre_drc.runset`. Execute:
```
calibre -drc -hier scripts/calibre_drc.runset 2>&1 | tee rpt/calibre_drc.log
```

Parse `drc_summary.rpt` for total violations.

#### Step B2: LVS

Read `scripts/calibre_lvs_template.runset`, fill placeholders:

| Placeholder | Value source |
|---|---|
| `{{GDS_PATH}}` | `output/gds/<design>.gds` |
| `{{NETLIST_PATH}}` | `output/pnr/<design>_final.v` |
| `{{TOP_MODULE}}` | spec.md → top module |
| `{{NETLIST_FORMAT}}` | VERILOG (for .v netlist) |
| `{{LVS_RULES_PATH}}` | eda_env.json → pdk.lvs_rules |
| `{{POWER_NETS}}` | VDD (from design) |
| `{{GROUND_NETS}}` | VSS (from design) |
| `{{RESULTS_DIR}}` | `rpt/calibre_lvs` |

Write to `scripts/calibre_lvs.runset`. Execute:
```
calibre -lvs -hier scripts/calibre_lvs.runset 2>&1 | tee rpt/calibre_lvs.log
```

Parse report for CORRECT/INCORRECT.

### Step 5: Assess signoff readiness

| Check | Pass criteria | Blocker if fail? |
|---|---|---|
| STA setup | WNS >= 0 | Yes |
| STA hold | WHS >= 0 | Yes |
| Power | Total < budget from spec | Yes |
| DRC | 0 violations | Yes |
| LVS | CORRECT | Yes |
| SPEF | File exists | Yes |

### Step 6: Route result

| Result | Route to | Action |
|---|---|---|
| All pass | `mcu-report-and-handoff` | Generate final report |
| STA fail | `mcu-pnr-implementation` (re-optimize) or `mcu-synthesis-planning` (constraint issue) | Rollback |
| DRC fail | `mcu-pnr-implementation` (fix routing) | Iterate PnR |
| LVS fail | `mcu-pnr-implementation` (connectivity issue) | Debug |
| Power over budget | `mcu-synthesis-planning` (clock gating) or `mcu-rtl-development` (RTL optimization) | Rollback |

## Signoff Quality Rules

### Signoff blocker checklist

Before declaring signoff readiness, verify:
- All required reports exist and are current (not stale relative to inputs)
- The reviewed corner set is explicit (ss/ff/tt — not assumed)
- Timing status (WNS/WHS) is distinguished from power status
- DRC and LVS status is explicit, not implied from clean timing
- Missing evidence is listed as a blocker until resolved

### Report consistency rules

- If extraction, timing, and power were not run on compatible inputs (same netlist, DEF, SDC revision), mark the result inconsistent
- If the netlist, DEF, and constraint versions differ across signoff checks, call out the mismatch
- If physical signoff is clean but timing context is stale, do **not** mark the design ready

## Bundled References

- [signoff-input-validation.md](references/signoff-input-validation.md) — stale input detection
- [timing-and-physical-failure-patterns.md](references/timing-and-physical-failure-patterns.md) — failure classification
- [engineering-thresholds.md](references/engineering-thresholds.md) — blocker vs warning bands

## Bundled Assets

- [signoff-summary-template.md](assets/signoff-summary-template.md) — signoff review output format
- [example-signoff-summary.md](assets/example-signoff-summary.md) — sample signoff review output
- [sample-signoff-metrics.json](assets/sample-signoff-metrics.json) — structured metrics example

## Bundled Scripts

- [starrc_cmd_template.txt](scripts/starrc_cmd_template.txt) — StarRC command file template (verified against MCP server)
- [pt_sta_template.tcl](scripts/pt_sta_template.tcl) — PrimeTime STA template (verified against MCP server)
- [pt_power_template.tcl](scripts/pt_power_template.tcl) — PrimeTime power template (verified against MCP server)
- [calibre_drc_template.runset](scripts/calibre_drc_template.runset) — Calibre DRC runset template (verified against MCP server)
- [calibre_lvs_template.runset](scripts/calibre_lvs_template.runset) — Calibre LVS runset template (verified against MCP server)
- [parse_pt_timing_summary.py](scripts/parse_pt_timing_summary.py) — PT timing report parser

> **Note:** All script templates above target the Synopsys + Calibre toolchain. Cadence equivalents (QRC, Tempus, ICV, Pegasus) are supported tool selections, but templates are not bundled. Users selecting Cadence tools must supply equivalent scripts/runsets.

## Completion Gate

- All 5 signoff scripts generated from templates with project-specific values
- Extraction executed, SPEF exists
- STA executed, WNS/WHS extracted
- Power analysis executed, total power extracted
- DRC and LVS executed, results parsed
- Signoff readiness assessed: all-pass or blockers identified with rollback guidance

## Decision Rules

- Separate missing evidence from passing evidence.
- Do not let one clean report hide another unresolved blocker.
- If timing, power, and physical evidence disagree, make the contradiction visible.
- Path A and Path B can run in parallel (extraction and DRC/LVS are independent).
- Back up previous signoff outputs before re-running.

## Known Tool Issues

See [references/known-tool-issues.md](references/known-tool-issues.md) for version-specific tool compatibility notes.
