---
name: mcu-report-and-handoff
description: Generate final project reports, milestone summaries, and deliverable inventories from MCU SoC engineering outputs. Use when the user needs to package stage results into doc/final_report.md for teammates, customers, or the next engineering phase.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# MCU Report And Handoff

Use this skill to convert engineering outputs into written reports and structured handoff records.

## Boundaries

- Do **not** run EDA tools. Only read existing report files.
- Do **not** fix issues found during report generation. Flag them in Open Issues.
- Do **not** modify RTL, TB, or constraint files.

## Two Modes

### Final Report Generation

Triggered when: all relevant stages have completed and a comprehensive project report is needed.

### Stage Handoff Summary

Triggered when: a specific stage has completed and results need to be packaged for the next stage or another team.

## Good Outcome

Produce:

- `doc/final_report.md` — comprehensive project report with PPA summary, verification status, signoff results
- or stage handoff summary with artifact inventory, blockers, assumptions
- deliverable file inventory with existence verification
- clear blocker/risk documentation

## Input Artifacts

| Artifact | Source | Required |
|----------|--------|----------|
| Specification (`doc/spec.md`) | From spec planning stage | For context |
| Synthesis reports (`rpt/syn_*.rpt`) | From synthesis stage | For PPA data |
| PnR reports (`rpt/pnr_*.rpt`) | From PnR stage | For PPA data |
| STA reports (`rpt/pt_*.rpt`) | From signoff stage | For timing closure |
| Power reports (`rpt/pt_power.rpt`) | From signoff stage | For power summary |
| DRC/LVS reports | From signoff stage | For physical signoff |
| Verification logs | From compile/sim stage | For verification status |
| Coverage reports | From regression/coverage stage | For coverage summary |
| Equivalence reports | From equivalence stage | For formal status |
| `eda_env.json` | From EDA env setup if available | For tool versions |

## Output Artifacts

| Artifact | Path | Description |
|----------|------|-------------|
| Final report | `doc/final_report.md` | Comprehensive project report |
| Stage handoff | `doc/handoff_<stage>.md` | Per-stage handoff summary |
| Artifact inventory | `doc/deliverable_inventory.json` | Structured file list with status |

## Input Validation

### For final report generation

Before generating the final report, scan the project directory and verify which stage outputs exist:

| Stage output | Path pattern | What to extract |
|---|---|---|
| Spec | `doc/spec.md` | Design name, target freq, power, process |
| RTL | `rtl/filelist.f` | Module count, lines of code |
| Synthesis timing | `rpt/syn_timing.rpt` | WNS, TNS |
| Synthesis area | `rpt/syn_area.rpt` | Total area, cell count |
| Synthesis power | `rpt/syn_power.rpt` | Dynamic, leakage, total power |
| PnR timing | `rpt/pnr_timing.rpt` | Post-route WNS |
| PnR hold | `rpt/pnr_hold_timing.rpt` | Post-route WHS |
| PnR area | `rpt/pnr_area.rpt` | Utilization |
| STA setup | `rpt/pt_timing_setup.rpt` | Signoff WNS, violation count |
| STA hold | `rpt/pt_timing_hold.rpt` | Signoff WHS, violation count |
| Power | `rpt/pt_power.rpt` | Total power vs budget |
| DRC | DRC summary report | Violation count |
| LVS | LVS summary report | CORRECT/INCORRECT |
| Equivalence | `rpt/fm_status.rpt` | PASS/FAIL |
| Verification | `sim/sim.log` | Pass/fail status |
| Coverage | Coverage report | Line/branch/FSM percentages |
| GDS | `output/gds/*.gds` | File exists, size |
| SPEF | `output/starrc/*.spef` | File exists |

Report files that are missing as "not available" rather than failing.

## Workflow — Final Report Generation

### Step 1: Scan project for available reports

Check each report path. For each file found, extract key metrics. For each file missing, note as "N/A" in the report.

### Step 2: Read specification for context

From `doc/spec.md`, extract:
- Design name, target frequency, power budget, process node
- Peripheral list and module count
- Clock domain count

### Step 3: Read tool versions

From `eda_env.json` (if available), extract selected tools and versions for the report.

### Step 4: Generate doc/final_report.md

Write `doc/final_report.md` with these sections:

**1. Project Summary**
- Design name, process node, target frequency/power/voltage
- Module count, approximate lines of RTL code
- Tool versions used

**2. Specification Achievement**

| Target | Spec value | Achieved value | Status |
|--------|-----------|----------------|--------|
| Frequency | from spec | from STA WNS | PASS/FAIL |
| Power | from spec | from PT power | PASS/FAIL |
| Area | N/A or estimate | from PnR | reported |

**3. PPA Summary (Performance, Power, Area)**

| Metric | Synthesis | Post-PnR | Signoff | Unit |
|--------|-----------|----------|---------|------|
| WNS (setup) | from syn rpt | from pnr rpt | from pt rpt | ns |
| WHS (hold) | N/A | from pnr rpt | from pt rpt | ns |
| Total area | from syn rpt | from pnr rpt | — | um2 |
| Utilization | — | from pnr rpt | — | % |
| Total power | from syn rpt | — | from pt rpt | mW |
| Cell count | from syn rpt | — | — | — |

Track PPA progression across stages: synthesis → PnR → signoff.

**4. Verification Summary**

| Item | Status | Detail |
|------|--------|--------|
| RTL compile | PASS/FAIL | from compile.log |
| Simulation | PASS/FAIL | from sim.log |
| Lint | N fatals, N errors | from lint report |
| CDC | PASS/FAIL | from CDC report |
| Coverage | line/branch/FSM % | from coverage report |
| UVM regression | N pass / N fail | from regression results |

**5. Formal Verification**

| Check | Status | Detail |
|-------|--------|--------|
| Equivalence (RTL vs netlist) | PASS/FAIL | from fm_status.rpt |
| Matched points | N | from equivalence report |

**6. Signoff Results**

| Check | Status | Detail |
|-------|--------|--------|
| STA setup | WNS value, violation count | from pt_timing_setup.rpt |
| STA hold | WHS value, violation count | from pt_timing_hold.rpt |
| Power | total mW vs budget | from pt_power.rpt |
| DRC | violation count | from DRC summary |
| LVS | CORRECT/INCORRECT | from LVS summary |
| SPEF | exists/missing | from output/starrc/ |
| GDS | exists/missing, file size | from output/gds/ |

**7. Deliverable Inventory**

| Deliverable | Path | Status |
|-------------|------|--------|
| Specification | doc/spec.md | exists/missing |
| Architecture | doc/architecture.md | exists/missing |
| RTL source | rtl/ | N files |
| Testbench | tb/ | N files |
| Synthesis netlist | output/syn/*_syn.v | exists/missing |
| Post-route netlist | output/pnr/*_final.v | exists/missing |
| Post-route DEF | output/pnr/*_final.def | exists/missing |
| SDC | sdc/*.sdc | exists/missing |
| SPEF | output/starrc/*.spef | exists/missing |
| GDS | output/gds/*.gds | exists/missing |
| Final report | doc/final_report.md | this file |

**8. Open Issues and Risks**

List any:
- Timing violations remaining
- DRC/LVS failures
- Coverage gaps
- Missing deliverables
- Assumptions that downstream work must preserve

### Step 5: Generate deliverable inventory JSON

Write `doc/deliverable_inventory.json`:

```json
{
  "timestamp": "...",
  "design": "...",
  "deliverables": [
    {"name": "RTL source", "path": "rtl/", "status": "exists", "file_count": 15},
    {"name": "Synthesis netlist", "path": "output/syn/mcu_top_syn.v", "status": "exists"},
    {"name": "GDS", "path": "output/gds/mcu_top.gds", "status": "missing"}
  ],
  "blockers": [],
  "open_risks": []
}
```

## Workflow — Stage Handoff Summary

### Step 1: Identify which stage to summarize

Read the stage outputs and determine scope.

### Step 2: Generate doc/handoff_<stage>.md

Write a concise handoff summary:
- What was done (1-3 sentences)
- Key results (metrics, pass/fail)
- Artifact list (what files were produced, where)
- Blockers (what is not resolved)
- Assumptions that downstream must preserve
- Recommended next step

### Step 3: Back up if overwriting

If a previous handoff summary exists, back up before overwriting.

## Report Quality Rules

### Fact vs inference

- Mark direct report results (WNS value, DRC count) as **facts**
- Mark cross-report synthesis (e.g., "timing is likely to close after PnR optimization") as **inference** — label it explicitly
- Mark absent artifacts as **missing evidence**, not silent success
- Never fabricate numbers — if a report file does not exist, state "N/A"

### Handoff content checklist

Every handoff document must answer:
- What stage was completed (run status + quality status)
- What evidence was reviewed (list specific report files)
- What is confirmed (metrics that meet targets)
- What is still missing or unresolved (blockers, open risks)
- What the next engineer should do first (one concrete action)

## Bundled References

- [stage-success-criteria.md](references/stage-success-criteria.md) — what "complete" means per stage

## Bundled Scripts

- [collect_artifacts.py](scripts/collect_artifacts.py) — scan project directory for expected stage outputs, report existence and file sizes as JSON. Run as: `python scripts/collect_artifacts.py <project_root>`

## Bundled Assets

- [handoff-summary-template.md](assets/handoff-summary-template.md) — stage handoff format
- [final-project-report-template.md](assets/final-project-report-template.md) — final report structure
- [example-final-handoff.md](assets/example-final-handoff.md) — example handoff
- [example-final-project-report.md](assets/example-final-project-report.md) — example final report
- [sample-artifact-inventory.json](assets/sample-artifact-inventory.json) — inventory schema

## Completion Gate

Final report:
- `doc/final_report.md` exists with all 8 sections
- PPA data extracted from actual reports (not guessed)
- Missing reports noted as "N/A" rather than fabricated
- Deliverable inventory JSON written
- Open issues explicitly listed

Stage handoff:
- Handoff summary written with artifacts, blockers, assumptions
- Previous version backed up if overwriting

## Decision Rules

- Only report metrics that come from actual tool output. Never fabricate numbers.
- If a report file is missing, state "not available" — do not skip the section silently.
- Distinguish "stage completed successfully" from "stage ran but failed" from "stage not executed."
- Write for reuse by another engineer who did not watch the work happen.
- Back up existing reports before overwriting.
