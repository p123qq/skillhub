# Stage Success Criteria

Use this reference when the summary needs to distinguish tool completion from engineering signoff quality.

- A stage may complete technically while still missing its quality target.
- Tool success should not be confused with timing closure, power closure, or verification sufficiency.
- Missing reports remain blockers even if upstream tools exited cleanly.
- Warnings may be acceptable, but they must not hide unresolved blockers or stale evidence.

Recommended wording pattern:

- `Run status`: whether the tool or stage completed
- `Quality status`: whether the engineering target was met
- `Blocking issues`: what still prevents true handoff
