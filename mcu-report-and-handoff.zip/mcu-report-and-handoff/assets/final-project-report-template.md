# Final Project Report: [Design Name]

## Project summary

Design name, process node, target frequency/power/voltage, module count, tool versions used. This section comes from spec.md and eda_env.json.

## Target versus achieved

| Target | Spec value | Achieved value | Source report | Status |
|--------|-----------|----------------|---------------|--------|
| Frequency | from spec | from STA WNS | pt_timing_setup.rpt | PASS/FAIL |
| Power | from spec | from PT power | pt_power.rpt | PASS/FAIL |
| Area | N/A | from PnR | pnr_area.rpt | reported |

## PPA progression

| Metric | Synthesis | Post-PnR | Signoff | Unit |
|--------|-----------|----------|---------|------|
| WNS (setup) | from syn rpt | from pnr rpt | from pt rpt | ns |
| WHS (hold) | N/A | from pnr rpt | from pt rpt | ns |
| Total area | from syn rpt | from pnr rpt | — | um2 |
| Total power | from syn rpt | — | from pt rpt | mW |

## Verification status

| Item | Status | Detail |
|------|--------|--------|
| RTL compile | PASS/FAIL | from compile.log |
| Simulation | PASS/FAIL | from sim.log |
| Coverage | line/branch/FSM % | from coverage report |
| Equivalence | PASS/FAIL | from fm_status.rpt |

## Implementation and signoff status

| Check | Status | Detail |
|-------|--------|--------|
| STA setup | WNS value | from pt_timing_setup.rpt |
| STA hold | WHS value | from pt_timing_hold.rpt |
| DRC | violation count | from DRC summary |
| LVS | CORRECT/INCORRECT | from LVS summary |

## Deliverable inventory

| Deliverable | Path | Status |
|-------------|------|--------|
| RTL source | rtl/ | N files |
| Synthesis netlist | output/syn/*_syn.v | exists/missing |
| GDS | output/gds/*.gds | exists/missing |
| ... | ... | ... |

## Known blockers and waivers

List any unresolved issues, accepted risks, or waived items with justification.

## Recommended next step

What should happen after this report: tapeout, further optimization, customer review, etc.
