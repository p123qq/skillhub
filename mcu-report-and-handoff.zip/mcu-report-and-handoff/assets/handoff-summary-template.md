# Stage Handoff: [Stage Name]

## Stage summary

1-3 sentences: what was done, which tool was used, and whether the stage completed successfully. Distinguish "tool ran to completion" from "engineering target met."

## Reviewed artifacts

List every file produced by this stage:

| Artifact | Path | Status |
|----------|------|--------|
| Netlist | output/syn/mcu_top_syn.v | exists |
| ... | ... | exists/missing |

## Confirmed blockers

List issues that the next stage cannot proceed without resolving:
- What is blocked
- Why it is blocked
- What action is needed (fix, user decision, upstream rollback)

If no blockers: "No blockers — stage output is ready for downstream use."

## Assumptions to preserve

List assumptions made during this stage that downstream work must not violate. For example:
- "Clock frequency is 100MHz — if changed, re-run synthesis"
- "Boot ROM is black-boxed — do not attempt to synthesize it"

## Recommended next step

One concrete action for the next engineer or stage.
