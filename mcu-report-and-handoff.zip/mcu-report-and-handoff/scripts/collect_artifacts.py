"""Scan project directory for stage artifacts and report existence/size.

Usage:
    python collect_artifacts.py <project_root>

Outputs JSON to stdout with status of each expected artifact.
"""
import glob
import json
import os
import sys


EXPECTED_ARTIFACTS = [
    {"name": "Spec",              "pattern": "doc/spec.md"},
    {"name": "Architecture",      "pattern": "doc/architecture.md"},
    {"name": "RTL filelist",      "pattern": "rtl/filelist.f"},
    {"name": "Synthesis timing",  "pattern": "rpt/syn_timing.rpt"},
    {"name": "Synthesis area",    "pattern": "rpt/syn_area.rpt"},
    {"name": "Synthesis power",   "pattern": "rpt/syn_power.rpt"},
    {"name": "Synthesis netlist",  "pattern": "output/syn/*_syn.v"},
    {"name": "PnR timing",       "pattern": "rpt/pnr_timing.rpt"},
    {"name": "PnR hold",         "pattern": "rpt/pnr_hold_timing.rpt"},
    {"name": "PnR area",         "pattern": "rpt/pnr_area.rpt"},
    {"name": "Post-route netlist", "pattern": "output/pnr/*_final.v"},
    {"name": "Post-route DEF",   "pattern": "output/pnr/*_final.def"},
    {"name": "Post-route SDC",   "pattern": "output/pnr/*_final.sdc"},
    {"name": "GDS",              "pattern": "output/gds/*.gds"},
    {"name": "SPEF",             "pattern": "output/starrc/*.spef"},
    {"name": "STA setup",        "pattern": "rpt/pt_timing_setup.rpt"},
    {"name": "STA hold",         "pattern": "rpt/pt_timing_hold.rpt"},
    {"name": "Power report",     "pattern": "rpt/pt_power.rpt"},
    {"name": "Equivalence",      "pattern": "rpt/fm_status.rpt"},
    {"name": "Sim log",          "pattern": "sim/sim.log"},
]


def main() -> int:
    if len(sys.argv) < 2:
        print("Usage: python collect_artifacts.py <project_root>", file=sys.stderr)
        return 1

    root = sys.argv[1]
    results = []
    for entry in EXPECTED_ARTIFACTS:
        full_pattern = os.path.join(root, entry["pattern"])
        matches = glob.glob(full_pattern)
        if matches:
            total_size = sum(os.path.getsize(f) for f in matches)
            results.append({
                "name": entry["name"],
                "pattern": entry["pattern"],
                "status": "found",
                "file_count": len(matches),
                "total_bytes": total_size,
                "files": [os.path.relpath(f, root) for f in matches],
            })
        else:
            results.append({
                "name": entry["name"],
                "pattern": entry["pattern"],
                "status": "not_found",
                "file_count": 0,
                "total_bytes": 0,
                "files": [],
            })

    json.dump(results, sys.stdout, indent=2)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
